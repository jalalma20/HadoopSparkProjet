package utils

class utils {


  // Créer une SparkSession
  def createSparkSession(appName: String): SparkSession = {
    SparkSession.builder()
      .appName(appName)
      .getOrCreate()
  }

  // Lire un fichier CSV et retourner un DataFrame
  def readCSV(spark: SparkSession, filePath: String): DataFrame = {
    spark.read.option("header", "true").csv(filePath)
  }

  // Écrire un DataFrame dans un fichier CSV
  def writeCSV(dataFrame: DataFrame, filePath: String): Unit = {
    dataFrame.write.option("header", "true").csv(filePath)
  }

  // Écrire un DataFrame dans un fichier Parquet
  def writeParquet(dataFrame: DataFrame, filePath: String): Unit = {
    dataFrame.write.parquet(filePath)
  }

}
