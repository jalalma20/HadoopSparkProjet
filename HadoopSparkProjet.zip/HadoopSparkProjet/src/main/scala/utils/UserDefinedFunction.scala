package utils

class UserDefinedFunction {

  // UDF : Additionne les colonnes "value" et "code"
  val addValueAndCodeUDF = udf((value: Double, code: String) => value + code.toInt)

}
