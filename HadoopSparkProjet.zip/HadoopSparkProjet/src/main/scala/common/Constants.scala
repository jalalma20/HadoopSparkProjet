package common

class Constants {

  // Déclaration des chaînes de caractères utilisées dans votre projet
  val appName = "HadoopSparkProjet"
  val csvFileName = "output_csv_full.csv"
  val csvFileName1 = "goods_classification.csv"
  val csvFileName2 = "services_classification.csv"
  val csvFileName3 = "country_classification.csv"
  val parquetFileName = "fichier.parquet"

}
