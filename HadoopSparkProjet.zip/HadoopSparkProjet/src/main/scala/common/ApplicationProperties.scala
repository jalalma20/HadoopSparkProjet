package common

class ApplicationProperties {
  // Déclaration des chemins pour l'entrée et les sorties
  val inputCSVPath = "C:/Users/Jalal/Desktop/Dataset/zip_dataset"
  val outputCSVPath = "C:/Users/Jalal/Desktop/Dataset/zip_dataset/output"
  val outputParquetPath = "C:/Users/Jalal/Desktop/Dataset/zip_dataset/output_parquet"

}
