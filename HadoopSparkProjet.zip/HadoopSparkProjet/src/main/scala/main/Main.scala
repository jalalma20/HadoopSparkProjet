package main

package com.example.sparkproject
import org.apache.spark.sql.{DataFrame, SparkSession}
import UserDefinedFunction._
import Utils._
import ApplicationProperties._


class Main {

  def main(args: Array[String]): Unit = {
    // Création de la SparkSession
    val spark = createSparkSession(appName)

    try {
      // Lecture du fichier CSV
      val inputDF = readCSV(spark, inputCSVPath)

      // Appel aux fonctions de création de DataFrame (résultats)
      val resultDF = inputDF
        .withColumn("sum_value_code", addValueAndCodeUDF(inputDF("value"), inputDF("code")))
      // Ajoutez d'autres transformations ou appels aux UDFs personnalisées ici si nécessaire

      // Affichage du DataFrame résultat
      resultDF.show()

      // Écriture du DataFrame résultat dans un fichier CSV
      writeCSV(resultDF, outputCSVPath)

      // Écriture du DataFrame résultat dans un fichier Parquet
      writeParquet(resultDF, outputParquetPath)

    } catch {
      case ex: Exception => println(s"An error occurred: ${ex.getMessage}")
    } finally {
      // Arrêt de la SparkSession
      spark.stop()
    }
  }

}
