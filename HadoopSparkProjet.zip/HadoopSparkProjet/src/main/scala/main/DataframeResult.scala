package main

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class DataframeResult {

  // Fonction pour ajouter une colonne date au format "01/06/2022" à partir de time_ref
  def addFormattedDate(df: DataFrame): DataFrame = {
    df.withColumn("date", to_date(lit("2022-06-01"), "yyyy-MM-dd"))
  }

  // Fonction pour ajouter une colonne "year" contenant l'année extraite de la colonne "date"
  def addYearColumn(df: DataFrame): DataFrame = {
    df.withColumn("year", year(col("date")))
  }

  // DataFrame contenant les codes pays et leur nom
  val countryCodesDF: DataFrame = ???
  // Vous devrez remplacer ??? par la façon dont vous allez charger le DataFrame contenant les noms de pays associés aux codes pays.

  // Fonction pour ajouter une colonne "nom_Pays" associant le code pays à son nom
  def addCountryNameColumn(df: DataFrame): DataFrame = {
    df.join(countryCodesDF, df("country_code") === countryCodesDF("code"), "left")
      .drop(countryCodesDF("code"))
      .withColumnRenamed("name", "nom_Pays")
  }

  // Fonction pour ajouter une colonne "détails_service" en filtrant sur le service
  def addDetailsServiceColumn(df: DataFrame, service: String): DataFrame = {
    df.filter(col("product_type") === service)
      .withColumn("détails_service", col("value"))
  }

  // Fonction pour ajouter une colonne "détails_goods" en filtrant sur le goods
  def addDetailsGoodsColumn(df: DataFrame, goods: String): DataFrame = {
    df.filter(col("product_type") === goods)
      .withColumn("détails_goods", col("value"))
  }

  // Fonction pour le classement des pays exportateurs par goods et services
  def exportCountriesRanking(df: DataFrame): DataFrame = {
    df.groupBy("country_code")
      .agg(
        sum(when(col("product_type") === "Goods", col("value"))).alias("total_exports_goods"),
        sum(when(col("product_type") === "Services", col("value"))).alias("total_exports_services")
      )
      .withColumn("exports_ranking", rank().over(Window.orderBy(col("total_exports_goods").desc, col("total_exports_services").desc)))
  }

  // Fonction pour le classement des pays importateurs par goods et services
  def importCountriesRanking(df: DataFrame): DataFrame = {
    df.groupBy("country_code")
      .agg(
        sum(when(col("product_type") === "Goods", col("value"))).alias("total_imports_goods"),
        sum(when(col("product_type") === "Services", col("value"))).alias("total_imports_services")
      )
      .withColumn("imports_ranking", rank().over(Window.orderBy(col("total_imports_goods").desc, col("total_imports_services").desc)))
  }

  // Fonction pour le regroupement par good
  def groupByGood(df: DataFrame): DataFrame = {
    df.groupBy("product_type")
      .agg(sum("value").alias("total_value"))
      .orderBy(col("total_value").desc)
  }

  // Fonction pour le regroupement par service
  def groupByService(df: DataFrame): DataFrame = {
    df.groupBy("product_type")
      .agg(sum("value").alias("total_value"))
      .orderBy(col("total_value").desc)
  }

  // Fonction pour la liste des services exportés de la France
  def servicesExportedByFrance(df: DataFrame): DataFrame = {
    df.filter(col("country_code") === "FR" && col("product_type") === "Services")
  }

  // Fonction pour la liste des goods importés par la France
  def goodsImportedByFrance(df: DataFrame): DataFrame = {
    df.filter(col("country_code") === "FR" && col("product_type") === "Goods")
  }

  // Fonction pour le classement des services les moins demandés
  def leastDemandedServices(df: DataFrame): DataFrame = {
    df.filter(col("product_type") === "Services")
      .groupBy("country_code")
      .agg(sum("value").alias("total_value"))
      .orderBy(col("total_value"))
  }

  // Fonction pour le classement des goods les plus demandés
  def mostDemandedGoods(df: DataFrame): DataFrame = {
    df.filter(col("product_type") === "Goods")
      .groupBy("country_code")
      .agg(sum("value").alias("total_value"))
      .orderBy(col("total_value").desc)
  }

  // Fonction pour ajouter une colonne "status_import_export" : si import > export : négative, sinon positive (par pays)
  def addStatusImportExportColumn(df: DataFrame): DataFrame = {
    df.withColumn("status_import_export", when(col("total_imports_goods") > col("total_exports_goods"), "négative").otherwise("positive"))
  }


  // Fonction pour ajouter une colonne "difference_import_export" : exports - imports (par pays)
  def addDifferenceImportExportColumn(df: DataFrame): DataFrame = {
    df.withColumn("difference_import_export", col("total_exports_goods") - col("total_imports_goods"))
  }

  // Fonction pour ajouter une colonne "Somme_good" calculant la somme des goods par pays
  def addSumGoodsColumn(df: DataFrame): DataFrame = {
    df.groupBy("country_code")
      .agg(sum(when(col("product_type") === "Goods", col("value"))).alias("Somme_good"))
      .join(df, Seq("country_code"), "left")
  }

  // Fonction pour ajouter une colonne "somme_service" calculant la somme des services par pays
  def addSumServicesColumn(df: DataFrame): DataFrame = {
    df.groupBy("country_code")
      .agg(sum(when(col("product_type") === "Services", col("value"))).alias("somme_service"))
      .join(df, Seq("country_code"), "left")
  }

  // Fonction pour ajouter une colonne "pourcentages_good" calculant le pourcentage de la colonne good par rapport à tous les goods d'un seul pays (regroupement par import et export)
  def addPercentageGoodsColumn(df: DataFrame): DataFrame = {
    df.withColumn("pourcentages_good", col("value") / sum(col("value")).over(Window.partitionBy("country_code", "product_type")) * 100)
  }

  // Fonction pour ajouter une colonne "pourcentages_service" calculant le pourcentage de la colonne service par rapport à tous les services d'un seul pays (regroupement par import et export)
  def addPercentageServicesColumn(df: DataFrame): DataFrame = {
    df.withColumn("pourcentages_service", col("value") / sum(col("value")).over(Window.partitionBy("country_code", "product_type")) * 100)
  }

  // Fonction pour regrouper les goods selon leur type (Code HS2)
  def groupByGoodsType(df: DataFrame): DataFrame = {
    df.groupBy("product_type")
      .agg(sum("value").alias("total_value"))
      .orderBy(col("total_value").desc)
  }

  // Fonction pour le classement des pays exportateurs de pétrole
  def oilExportingCountriesRanking(df: DataFrame): DataFrame = {
    df.filter(col("product_type") === "Goods" && col("code") === "petrole_code") // Remplacez "petrole_code" par le code correspondant aux exportations de pétrole
      .groupBy("country_code")
      .agg(sum("value").alias("total_oil_exports"))
      .orderBy(col("total_oil_exports").desc)
  }

  // Fonction pour le classement des pays importateurs de viandes
  def meatImportingCountriesRanking(df: DataFrame): DataFrame = {
    df.filter(col("product_type") === "Goods" && col("code") === "viandes_code") // Remplacez "viandes_code" par le code correspondant aux importations de viandes
      .groupBy("country_code")
      .agg(sum("value").alias("total_meat_imports"))
      .orderBy(col("total_meat_imports").desc)
  }

  // Fonction pour le classement des pays ayant le plus de demandes sur les services informatiques
  def computerServicesDemandRanking(df: DataFrame): DataFrame = {
    df.filter(col("product_type") === "Services" && (col("code") === "computer_services_code" || col("code") === "computer_software_code" || col("code") === "other_computer_services_code")) // Remplacez les codes par les codes correspondants aux services informatiques
      .groupBy("country_code")
      .agg(sum("value").alias("total_computer_services_demand"))
      .orderBy(col("total_computer_services_demand").desc)
  }

  // Fonction pour ajouter une colonne "description" : le pays XXXX fait un [IMPORT ou EXPORT] sur [goods ou Services]
  def addDescriptionColumn(df: DataFrame): DataFrame = {
    df.withColumn("description", concat(lit("Le pays "), col("nom_Pays"), lit(" fait un "), when(col("total_imports_goods") > col("total_exports_goods"), "IMPORT").otherwise("EXPORT"), lit(" sur "), when(col("product_type") === "Goods", "Goods").otherwise("Services")))
  }

}
